public class Rectangle {
    private double height;
    private double width;
    public Rectangle(double width, double height){
        setHeight(height);
        this.setWidth(width);
    }
    public void setHeight(double height){
        this.height = height ;
    }
    public void setWidth(double width){
        this.width = width;
    }
    public double getHeight(){
        return height;
    }
    public double getWidth(){
        return width;
    }
    public double getArea() {
        return height*width;
    }
}
