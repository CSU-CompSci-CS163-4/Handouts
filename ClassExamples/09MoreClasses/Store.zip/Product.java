import java.util.Random;
public class Product {
    private String name;
    private double price;
    private int quantity;
    private final static Random RAN = new Random();
    public Product(String name){
        setName(name);
        setPrice(9.99);
        setQuantity(1);
    }
    public Product(String name, double price, int quantity){
        setName(name);
        setPrice(price);
        setQuantity(quantity);
    }
    public void setName(String name){
        this.name = name;
    }
    public void setPrice(double price){
        if(price < 9.99) this.price = 9.99;
        else this.price = price;
    }
    public void setQuantity(int quantity){
        if(quantity < 1) this.quantity = 1;
        else this.quantity = quantity;
    }
    public String getName(){
        return name;
    }
    public double getPrice(){
        return price;
    }
    public int getQuantity(){
        return quantity;
    }
    public void randomlyChangePrice(){
        double value = price * (RAN.nextDouble()-0.1);
        price += value;
    }
    public String toString(){
        String msg = String.format("Name: %s, Price: %.2f, Quantity: %d\n", name, price, quantity);
        return msg;
    }
}
