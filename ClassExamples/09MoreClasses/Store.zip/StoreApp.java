public class StoreApp {
    private Store store;
    private StoreView view;
    public StoreApp(String name){
        store = new Store(name);
        view = new StoreView();
    }
    public void go(){
        view.printMenu();
        System.out.println("What would you like to do?");
        String action = view.getInput();
        while(!action.startsWith("x")) {
            if (action.startsWith("a")) {
                System.out.println("Enter the name of the product: ");
                String name = view.getInput();
                System.out.println("Enter the price of the product: ");
                double price = Double.parseDouble(view.getInput());
                System.out.println("Enter the quantity of the product: ");
                int quantity = Integer.parseInt(view.getInput());
                if(store.addProduct(name, price, quantity))
                    System.out.println("Product added!");
                else System.out.println("Could not add product, store is full!");
            } else if (action.startsWith("l")) {
                System.out.println(store.toString());
            } else if (action.startsWith("r")) {
                System.out.println("Enter the name of the product you will randomly change the price: ");
                String name = view.getInput();
                store.randomChange(name);
            } else {
                System.out.println("Please enter a valid command.");
            }
            view.printMenu();
            System.out.println("What would you like to do?");
            action = view.getInput();
        }
    }
    public static void main(String args[]){
        StoreApp app = new StoreApp("STORE");
        app.go();
    }
}
