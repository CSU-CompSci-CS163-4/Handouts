import java.util.Scanner;
public class StoreView {
        private final Scanner scanner;
        public StoreView() {
            scanner = new Scanner(System.in);
        }
        public void printMenu() {
            System.out.println("Type \"X\" to exit at any time.");
            System.out.println("[A]dd products");
            System.out.println("[L]ist products");
            System.out.println("[R]andomly change price");
            System.out.println();
        }
        public String getInput() {
            return scanner.nextLine().toLowerCase();
        }
}
