import java.util.Scanner;

public class AppStore {
    private Store store;
    private final Scanner scanner;
    public AppStore(String name){
        store = new Store(name);
        scanner = new Scanner(System.in);
    }
    public void printMenu() {
        System.out.println("Type \"X\" to exit at any time.");
        System.out.println("[A]dd products");
        System.out.println("[L]ist products");
        System.out.println("[C]hange price");
        System.out.println();
    }

    public void go(){
        printMenu();
        System.out.println("What would you like to do?");
        String action = scanner.nextLine().toLowerCase();
        while(!action.startsWith("x")) {
            if (action.startsWith("a")) {
                System.out.println("Enter the name of the product: ");
                String name = scanner.nextLine().toLowerCase();
                System.out.println("Enter the price of the product: ");
                double price = scanner.nextDouble();
                System.out.println("Enter the quantity of the product: ");
                int quantity = scanner.nextInt();
                if(store.addProduct(name, price, quantity))
                    System.out.println("Product added!");
                else System.out.println("Could not add product, store is full!");
            } else if (action.startsWith("l")) {
                System.out.println(store.toString());
            } else if (action.startsWith("c")) {
                System.out.println("Enter the name of the product you will randomly change the price: ");
                String name = scanner.nextLine().toLowerCase();
                store.randomChange(name);
            } else {
                System.out.println("Please enter a valid command.");
            }
            printMenu();
            System.out.println("What would you like to do?");
            action = scanner.nextLine().toLowerCase();
        }
    }
    public static void main(String args[]){
        AppStore app = new AppStore("STORE");
        app.go();
    }
}
