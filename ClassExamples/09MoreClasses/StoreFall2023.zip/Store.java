public class Store {
    private String name;
    private Product p1, p2, p3;
    public Store(String name){
        this.name = name;
        p1=p2=p3=null;
    }
    public String getName(){         return name;     }
    public boolean addProduct(String name, double price, int quantity){
        if(p1 != null && p2 !=null && p3 != null)
            return false;
        Product p = new Product(name,price, quantity);
        if(p1 == null) p1 = p;
        else if(p2 == null) p2 = p;
        else if(p3 == null) p3 = p;
        return true;
    }
    public void randomChange(String name){
        if(p1 != null && name.equalsIgnoreCase(p1.getName()))
            p1.changePrice();
        else if(p2 != null && name.equalsIgnoreCase(p2.getName()))
            p2.changePrice();
        else if(p3 != null && name.equalsIgnoreCase(p3.getName()))
            p3.changePrice();
    }
    public String toString(){
        String msg = name + "\n";
        if(p1!=null) msg += p1.toString() + "\n";
        if(p2!=null) msg += p2.toString() + "\n";
        if(p3!=null) msg += p3.toString() + "\n";
        if(msg.equals(name + "\n")) return "No Products in Store!\n";
        return msg;
    }
}

