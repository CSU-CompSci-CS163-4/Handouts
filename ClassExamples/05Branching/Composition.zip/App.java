public class App {
    public static void main(String args[]){
        Person owner = new Person("Maria", "9990001234");
        Animal animal = new Animal("puppy", 1, owner);
        System.out.println(animal.toString());
    }
}
