public class Animal {
    private String name;
    private int yearsOld;
    private Person owner;

    public Animal(String name, int years, Person owner){
        this. name = name;
        this.yearsOld = years;
        this.owner = owner;
    }
    /**
     * Implement sets and gets for all instance variables
     */
    public String toString(){
        return String.format("Animal name: %s, Years old: %d\nOwners Info\n%s", name, yearsOld, owner.toString());
    }
}
