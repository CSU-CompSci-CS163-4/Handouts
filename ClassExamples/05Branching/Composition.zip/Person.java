public class Person {
    private String name;
    private String phone;

    public Person(String name, String phone){
        setName(name);
        setPhone(phone);
    }
    public void setName(String name){
        this.name = name;
    }
    public void setPhone(String phone){
        this.phone = phone;
    }
    public String toString(){
        return String.format("Name: %s\nPhone:%s\n", name, phone);
    }
}
